"use strict";

class MouseHandler {

    constructor(){

}

}