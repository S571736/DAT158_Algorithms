# Exercise 2

## Problem 1

1. Choose subset S1 as this has the lowest weight with 2/3= 0.67

visited nodes = {1,2,5}

2. remove the nodes from all subsets, and repeat. Select S2 as this is the next lowest with 4/2 = 2

Visited nodes = {1,2,5,3,4}

We have now visited all of the nodes

## Problem 2

a) objective function is:

4x + 7y + 6z

b) Decision variables are x, y and z

c) the constraints are: 
x + 2y + z <= 7
2x + y + 3z <= 14
x + 4y + 2z <= 11

d)

* x = 1, y = 1, z = 2
* x = 5, y = 1, z = 1

e)

* x = 3, y = 4, z = 2
* x = 2, y = 3, z = 5

## Problem 3
a)
<p>minimize 2x<sub>1</sub> + 4x<sub>2</sub> + 5x<sub>3</sub> + 6x<sub>4</sub> + 8x<sub>5</sub> + 3x<sub>6</sub></p>

x1 + x2                >= 1

x1 + x3 + x4           >= 1

x2 + x5 +              >= 1

x2 + x4 + x5 + x6      >= 1

x1 + x3 + x4 + x5 + x6 >= 1

<p>x<sub>i</sub> &#8712; {0,1}, 1,...,6</p>
b)
LP: 0 <= Xu <= 1

c)
